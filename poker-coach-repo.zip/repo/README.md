# Poker Coach

Six-handed No-Limit Texas Hold'em against five Claude opponents, where every decision you make gets graded afterwards.

You sit down with 500 chips. So does everyone else. Blinds are 5/10. When a hand ends, the right-hand column — *The Margin* — marks up each decision you made: the price you were offered, the equity you actually held, and the better line. Decisions are judged on the information available at the time, not on the result, so a correct call that lost is still graded as correct and a lucky win is still a mistake.

## The table

| Player | Style | VPIP/PFR | How they play |
| --- | --- | --- | --- |
| **Bishop** | The Rock | 12/9 | Folds almost everything, never bluffs, sizes value bets large |
| **Marla** | The Maniac | 58/44 | Raises constantly, barrels every street, huge bluffs |
| **Otto** | The Station | 44/6 | Calls with any piece of the board, raises only the nuts |
| **Nash** | The Solver | 24/19 | Balanced and near-GTO, small c-bets, polarised turn and river sizing |
| **Ruby** | The Reader | 30/24 | Plays *you* — tracks your fold rate and attacks whichever way you lean |

Ruby is the one to watch. She's fed your running VPIP, fold rate and raise rate, so if you start folding to every river bet she will notice and start firing at every river.

## Fair play

Each opponent is sent only its own two cards, the community cards and the public betting action. Your hole cards are never in an opponent's prompt. The bots can't see your hand, and neither can each other's.

Showdowns follow real table rules: the last aggressor tables first, and after that you only turn your cards over if you can beat what's already face up. Lose a pot and your hand goes into the muck unseen. Win one and you have to show it.

## Running it

The prebuilt bundle is committed, so the fastest path is just to serve the folder:

```bash
python3 -m http.server 8000     # then open http://localhost:8000
```

To develop against it:

```bash
npm install
npm run dev      # esbuild watch + dev server on :8000
npm run build    # regenerates app.js
```

## API key

Opponent decisions and hand reviews are Claude calls, so the standalone version needs your own Anthropic API key. Paste it into the bar at the top of the page. It's kept in that browser's local storage and sent only to `api.anthropic.com`.

Without a key everything still runs: the opponents fall back to local rule-based logic built around Monte Carlo equity and pot odds, and the coach falls back to an offline reviewer that scores your decisions on price versus equity. You lose the table talk and the range-level commentary, not the game.

Costs are small — roughly one short call per opponent decision plus one longer call per hand review.

## Deploying

The included workflow (`.github/workflows/pages.yml`) builds and publishes to GitHub Pages on every push to `main`. Enable it under **Settings → Pages → Source → GitHub Actions**.

Anyone visiting the deployed page supplies their own key, so you are not paying for other people's poker.

## What's under the hood

- **Hand evaluation** — exhaustive best-five-of-seven over all 21 combinations, returning a comparable score vector. No lookup tables, no approximations.
- **Equity** — Monte Carlo rollouts against random opponent holdings, 200–450 iterations per decision depending on whether it's yours or a bot's.
- **Side pots** — settled by contribution level, so unequal all-ins split correctly and folded players' chips stay in the pot they belong to.
- **Coaching** — each of your decisions is logged with pot size, price to call, pot odds, your true all-in equity and the number of live opponents. That record is what the coach reviews, which is why the notes come back in chips and percentages rather than platitudes.

The engine was simulated over 500+ full games to check that chips are conserved exactly, that no betting round can stall, and that the showdown rules hold.

## Layout

```
index.html              page shell
app.js                  prebuilt bundle (committed so Pages needs no build)
src/PokerCoach.jsx      the whole game: engine, opponents, coach, UI
src/main.jsx            standalone entry point and API key bar
```

`src/PokerCoach.jsx` has no dependency on the key bar or on local storage, so the same file drops straight into a Claude artifact where the API call is handled for you.

## License

MIT.
