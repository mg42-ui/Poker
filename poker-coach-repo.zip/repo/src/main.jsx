import React, { useState } from "react";
import { createRoot } from "react-dom/client";
import PokerCoach from "./PokerCoach.jsx";

/* The game asks for an API key through this global. Kept out of the game file so
   the same component can run unchanged inside a Claude artifact, where the key
   is handled for you. */
const LS = "poker-coach-key";
let key = "";
try { key = localStorage.getItem(LS) || ""; } catch (e) {}
window.__pokerKey = () => key;

function KeyBar() {
  const [val, setVal] = useState(key);
  const [saved, setSaved] = useState(!!key);
  function save() {
    key = val.trim();
    try { localStorage.setItem(LS, key); } catch (e) {}
    setSaved(!!key);
  }
  return (
    <div style={{ background: "#221C18", borderBottom: "1px solid #3A322C", padding: "10px 16px",
      display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap",
      fontFamily: "Inter, Helvetica, Arial, sans-serif", fontSize: 12, color: "#C9BFAE" }}>
      <span style={{ letterSpacing: ".14em", textTransform: "uppercase", fontSize: 10, color: saved ? "#8FA76B" : "#C79A3C" }}>
        {saved ? "Key saved" : "Anthropic API key"}
      </span>
      <input type="password" value={val} placeholder="sk-ant-..." onChange={(e) => setVal(e.target.value)}
        style={{ flex: "1 1 260px", padding: "7px 9px", borderRadius: 5, border: "1px solid #3A322C",
          background: "#171310", color: "#EFE7D9", fontFamily: "ui-monospace, Menlo, monospace", fontSize: 12 }} />
      <button onClick={save} style={{ padding: "7px 14px", borderRadius: 5, border: "1px solid #C79A3C",
        background: "#C79A3C", color: "#171310", fontWeight: 600, cursor: "pointer", fontSize: 12 }}>Save</button>
      <span style={{ flex: "1 1 200px", minWidth: 180 }}>
        Stored in this browser only, never sent anywhere but api.anthropic.com. Without a key the table falls
        back to local rule-based opponents and the offline coach, which still work.
      </span>
    </div>
  );
}

createRoot(document.getElementById("root")).render(
  <React.StrictMode><KeyBar /><PokerCoach standalone /></React.StrictMode>
);
